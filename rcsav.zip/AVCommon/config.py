__author__ = 'fabrizio'

class Box:
    def __init__(self):
        pass
    pass

__box = Box()


verbose = False
basedir = False